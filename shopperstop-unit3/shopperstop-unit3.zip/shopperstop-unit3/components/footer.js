function footer(){
    return ` <div id="info_foot">
    <div>
      <p>DOWNLOAD THE APP ON</p>
      <div id="store_app">
        <img src="https://www.netmeds.com/assets/gloryweb/images/icons/app_store.png">
        <img src="https://www.netmeds.com/assets/gloryweb/images/icons/play_store.png">
      </div>
    </div>

    <div id="facility">
      <div><img id="info_logo" src="https://cdn-icons-png.flaticon.com/512/3712/3712105.png">
        <p>Authentic</br> Products</p>
      </div>
      <div><img id="info_logo" src="https://cdn-icons-png.flaticon.com/512/175/175461.png">
        <p>Free</br>Delivery</p>
      </div>
      <div><img id="info_logo" src="https://cdn-icons-png.flaticon.com/512/1428/1428459.png">
        <p>Easy</br> Exchange</br>and Return </p>
      </div>
      <div><img id="info_logo" src="https://cdn-icons-png.flaticon.com/512/93/93375.png">
        <p>Express</br>Store</br>Pickup</p>
      </div>
      </div>
      <div>
        <p>FOLLOW US</p>
      <div id="social_app">
        <img src="https://cdn-icons-png.flaticon.com/512/20/20837.png">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733635.png">
        <img src="https://cdn-icons-png.flaticon.com/512/87/87390.png">
      </div>
    </div>
  </div>

<div id="footer_cat"> 
<div>
<ul><p class="h3">WOMEN</p></ul>  
<ul>Indian Wear</ul>
<ul> Western Wear</ul>
<ul>  Lingerie & Night Wear</ul>
<ul> Footwear</ul>
<ul> Watches</ul>
<ul> Fragrances</ul>
<ul> Bags & Wallets</ul>
<ul>Sunglasses & Frames</ul>
<ul> Jewellery</ul>
<ul>Travel</ul>
</div>

<div><ul><p class="h3"> MEN</p></ul>
 <ul>Clothing</ul>
<ul>Footwear</ul>
<ul>  Watches</ul>
<ul> Fragrances</ul>
<ul> Grooming For Men</ul>
<ul> Sunglasses & Frames</ul>
<ul> Accessories</ul>
<ul> Jewellery</ul>
</div>

  <div><ul><h3 class="h3">KIDS</h3></ul>
    <ul>Boys</ul>
    <ul>Girls</ul>
    <ul>  Infants</ul>
    <ul> Toys</ul>
    <ul> School Essential</ul>
    <ul> Footwear</ul>
    <ul> Watches</ul>
    <ul> Accessories</ul>
    </div>

    
<div><ul><p class="h3"> BEAUTY</p></ul>
  <ul>Make Up</ul>
 <ul>Skincare</ul>
 <ul>  Bath & Body</ul>
 <ul> Nails</ul>
 <ul> Hairs</ul>
 <ul> Tools & Accessories</ul>
 <ul> Women's Fragrances</ul>
 <ul> Men's Fragrances</ul>
 <ul> Grooming For Men</ul>
 <ul> Personal Hygiene</ul>
 </div>

 <div><ul><p class="h3"> HOMESTOP</p></ul>
  <ul>Kichen & Dining</ul>
 <ul>Decor</ul>
 <ul>  House Furnishing</ul>
 <ul> Storage & Organization</ul>
 <ul> Smart Home and Appliances</ul>
 <ul> Bath</ul>
 <ul> Bedding</ul>
 </div>

 <div><ul><p class="h3"> WATCHES</p></ul>
  <ul>Mens Watches</ul>
 <ul>Women Watches</ul>
 <ul>  Kids Watches</ul>
 </div>
</div>

<div id="customer_care">
<div><ul><p class="cust_white"> CUSTOMER</p></ul>
  <ul>HELP&FAQS</ul>
 <ul>TRACK ORDER</ul>
 <ul>SIZE GUIDE</ul>
 <ul>BUYING GUIDE</ul>
 <ul>HOW DO I SHOP?</ul>
 <ul>HOW DO I PAY?</ul>
 </div>

 <div><ul><p class="cust_white"> POLICIES</p></ul>
  <ul>TERMS OF USE </ul>
 <ul>PRIVACY</ul>
 <ul>DELIVERY POLICY</ul>
 <ul>BUYING GUIDE</ul>
 <ul>EXCHANGES & RETURNS</ul>
 </div>

 <div><ul><p class="cust_white">STORE AND SITES</p></ul>
  <ul>ABOUT US</ul>
 <ul>CONTACT US</ul>
 <ul>CORPORATE SITE</ul>
 <ul>STORE LOCATOR</ul>
 <ul>CAREERS</ul>
 <ul>SITEMAP</ul>
 </div>

 <div><ul><p class="cust_white">DELIGHTFUL PROGRAMS</p></ul>
  <ul>INSTANT GIFTING</ul>
 <ul> EXPRESS STORE PICK UP</ul>
 </div>

 <div><ul><p class="cust_white">FIRST CITIZEN</p></ul>
  <ul>FIRST CITIZEN</ul>
  <ul>

    <select  id="BRAND">
      <option >BRAND</option>
      <option >Reebok</option>
      <option >adidas</option>
      <option >puma</option>
    </select></ul>
 </div>

 <div><ul><p class="cust_white">REACH US</p></ul>
  <ul>FOR ANY QUERY PLEASE EMAIL<br> US</ul>
  <ul>customercare@shoppersstop.com</ul>
 </div>
</div>
<div id="foot_details">
<p id="foot_head">Most Searched Brands on Shoppersstop.com </p>
<p>Watches: FOSSIL | TITAN | MK | CASIO | TOMMY | ARMANI EXCHANGE |
   EMPORIO ARMANI | GUESS | TIMEX | GIORDANO | CITIZEN | DANIEL WELLINGTON | VERSUS | TISSOT | CERRUTI</p>

<p>Apparel: AND | VEROMODA | U.S POLO ASSN | TOMMY HILFIGER 
     | STOP | CALVIN KLEIN JEANS | JACK & JONES | MOTHERCARE | HAUTE CURRY | W | ZINK LONDON</p>

<p>Shoes:WOODLAND SHOES | REDTAPE SHOES | CLARK SHOES | INC.5 |
 CATWALK | STEVE MADDEN | REEBOK | TRESMODE | PUMA | ADIDAS</p> 

<p>Handbags: LAVIE | HIDESIGN | BAGGIT | CAPRESE | HOLII | GIORDANO</p>

<p>Beauty: LAKME | L'OREAL | MAYBELLINE | REVLON | COLORBAR 
| MAC | CLINIQUE | ESTEE LAUDER | BOBBI BROWN | BURBERRY</p>

<p>Home: PHILIPS | WONDERCHEF | FERN | TREASURES | SPACES |
 IVY | DEVON NORTH | MASPAR | SPREAD | MEYER | LIVING WORLD | BACK TO EARTH</p>

<p>Sunglasses: OPIUM | TOMMY HILFIGER | CARRERA | IDEE | CK | RAYBAN |
 OAKLEY | VOGUE | SCOTT | FCUK | POLAROID | VELOCITY | TOM FORD | BEBE | GIO COLLECTION</p>

<p>Jewellery: SHAZE | VOYLLA | SWAROVSKI | YELLOW CHIMES |FOSSIL | AYESHA | SKAGEN | PRETTY WOMEN | ARMANI | MICHAEL KORS 
 | ACCESSORIZE | DANIEL WELLINGTON | TRIBAL ZONE | REAL EFFECT</p>
</div>


<div id="foot_details">
<p id="foot_head">Shoppersstop.com: Shop Anytime, Anywhere!</p>
<p>Online shopping is taking over the market faster than one can comprehend. That being said, no one else knows or understands the retail market better than Shoppers Stop. Being one of India’s finest retailers for more than 30 years,
   we are at the forefront when it comes to retail development. We are expanding our reach over retail stores and the digital market with one of the best online shopping sites in India. Shopping online can sometimes be tedious and difficult, however, our online fashion store is easy to navigate making your 
  experience delightful. One can browse through exclusive offers and bag some of the best deals available for themselves. Best deals on top categories, free shipping* and options like cash on delivery to provide you with a hassle-free online shopping experience to ‘Shop Anytime Anywhere’.</p>

<p>
  Shoppersstop.com is a one-stop destination for your family's fashion needs. We give you the opportunity to give your wardrobe a makeover with the latest collections from our top brands. Shoppers Stop aims at ensuring nothing but the best for your closet.
   Find everything in one place, whether it is women’s ethnic wear from W & Biba, Haute Curry or salwar & churidar sets from brands like Kashish & Global Desi. The most desired dresses or the latest styles in tops and tees is no more a challenge to find from brands like AND, Only, 
  Levis and many more. Choose from an enviable collection of women’s watches to make a style impact. You can choose from our massive collection of handbags that can directly make way through your go-to collection for all occasions. Beauty lovers can shop for the best makeup brands like MAC, Smash box, Bobbi Brown available at Shoppers Stop.
</p>

<p>
  Mothers can find everything for their little ones right from birth to teenage from our exclusive brands Karrot, Life. The wide range of apparel, toys, games from Hamleys & other accessories for your kids ensures you have an unmatched experience while shopping for your kids. For the homemakers who want to redesign their abode, we offer easy
   and attractive home décor solutions. Turn your living room or bedroom into a lively space with upholstery from brands like Treasures, Ivy, Portico, etc. Choose your kitchen appliances from trusted companies like Wonder Chef or Phillips at the click of a button.
</p>
<p>
  While women enjoy retail therapy, men can have their share of hassle-free shopping experience to buy clothes online with our Omni channel presence. The search does not end at quirky tees, formal or casual shirts. From the boardroom to the beach, 
  find everything that your heart desires from the best of brands like Allen Solly, U.S. Polo, Fratini, Infuse, Stop and many others.
</p>

<p>
  Add a dash of style to your outfit with a choice of swanky watches from brands like Fastrack, Guess, Fossil and Casio amongst others. Flaunt your fashion sense in those cool pair of sunglasses from Rayban, IDEE & more.
</p>

<p>
  For those who love a good fragrance, you will find plenty of options in men’s deodorants & fragrances to choose from brands like Ferrari, Armani, Bvlgari, YSL, Arcelia, etc. Your search for the perfect pair of shoes ends 
  at shoppersstop.com, from the best assortment of footwear brands like Lee Cooper, Clarks, Louis Philippe, Red Tape, etc.
</p>

<p>
  Celebrity brands like Being Human & many more lay trust in us by launching with us exclusively.  Our Endless Aisle services will assist you in finding anything you liked but could not find in your size or colour in the store
   on shopperstop.com and delivering it to your door. Shoppers Stop not only allows you to shop your favourite brands online from the comfort of your home but also leaves you wanting more with our exclusive sales and best offers.

</p>
</div>
</div>
`
}

export default footer; 